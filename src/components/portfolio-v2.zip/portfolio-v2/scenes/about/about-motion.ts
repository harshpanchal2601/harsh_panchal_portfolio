import {
  gsap,
  ScrollTrigger,
} from "@/animations/gsap/register-plugins";

import { createSceneContext } from "@/components/portfolio-v2/motion/scene-context";

type MotionMode = "desktop" | "mobile";

const WORD_MUTED = "rgba(23, 19, 15, 0.15)";
const WORD_ACCENT = "#B96143";
const WORD_INK = "#17130F";

const CLIP_TILE_HIDDEN = "inset(100% 0% 0% 0%)";
const CLIP_TILE_OPEN = "inset(0% 0% 0% 0%)";

const ABOUT_TRIGGER_ID = "v2-about-copy";

function killAboutTriggers(): void {
  [
    ABOUT_TRIGGER_ID,
    `${ABOUT_TRIGGER_ID}-lead`,
    `${ABOUT_TRIGGER_ID}-follow`,
    `${ABOUT_TRIGGER_ID}-tile`,
    `${ABOUT_TRIGGER_ID}-proof`,
  ].forEach((id) => {
    ScrollTrigger.getById(id)?.kill();
  });
}

function settleAbout(scope: HTMLElement): void {
  const select = gsap.utils.selector(scope);

  gsap.set(select("[data-word]"), {
    color: WORD_INK,
  });

  gsap.set(select(".v2-about-proof"), {
    autoAlpha: 1,
    y: 0,
  });

  gsap.set(select("[data-about-tile]"), {
    clipPath: CLIP_TILE_OPEN,
    y: 0,
  });

  gsap.set(select("[data-about-chip]"), {
    y: 0,
  });
}

function revealWords(
  timeline: gsap.core.Timeline,
  words: HTMLElement[],
  start: number,
  end: number,
  activeWindow = 2.6,
): void {
  const count = words.length;

  if (!count) {
    return;
  }

  const span = end - start;
  const step = span / (count + activeWindow);

  words.forEach((word, index) => {
    const at = start + index * step;
    const toAccent = step * activeWindow * 0.42;
    const toInk = step * activeWindow * 0.58;

    timeline.fromTo(
      word,
      {
        color: WORD_MUTED,
      },
      {
        color: WORD_ACCENT,
        duration: toAccent,
        ease: "none",
      },
      at,
    );

    timeline.to(
      word,
      {
        color: WORD_INK,
        duration: toInk,
        ease: "none",
      },
      at + toAccent,
    );
  });
}

function buildAboutTimeline(
  scope: HTMLElement,
  mode: MotionMode,
): () => void {
  killAboutTriggers();

  const select = gsap.utils.selector(scope);
  const desktop = mode === "desktop";

  const stage = select(".v2-about-stage")[0] as HTMLElement | undefined;
  const proof = select(".v2-about-proof");
  const tile = select("[data-about-tile]");
  const chips = select("[data-about-chip]");
  const leadWords = gsap.utils.toArray<HTMLElement>(
    select(".v2-about-lead [data-word]"),
  );
  const fastWords = gsap.utils.toArray<HTMLElement>(
    select('.v2-about-follow [data-word-pace="fast"]'),
  );
  const restWords = gsap.utils.toArray<HTMLElement>(
    select(".v2-about-follow [data-word]:not([data-word-pace])"),
  );

  gsap.set([...leadWords, ...fastWords, ...restWords], {
    color: WORD_MUTED,
  });

  gsap.set(proof, {
    autoAlpha: desktop ? 0.28 : 0.4,
    y: desktop ? 10 : 0,
  });

  gsap.set(tile, {
    clipPath: CLIP_TILE_HIDDEN,
    y: desktop ? 28 : 18,
  });

  gsap.set(chips, {
    y: 0,
  });

  if (desktop && stage) {
    const timeline = gsap.timeline({
      defaults: {
        ease: "none",
      },
      scrollTrigger: {
        id: ABOUT_TRIGGER_ID,
        trigger: scope,
        start: "top top",
        end: "+=158%",
        pin: stage,
        pinSpacing: true,
        scrub: true,
        anticipatePin: 1,
        invalidateOnRefresh: true,
      },
    });

    timeline.to(
      proof,
      {
        autoAlpha: 1,
        y: 0,
        duration: 0.1,
      },
      0,
    );

    revealWords(timeline, leadWords, 0.04, 0.54, 2.8);

    revealWords(timeline, fastWords, 0.56, 0.66, 1.15);

    revealWords(timeline, restWords, 0.64, 0.88, 2.4);

    timeline.to(
      tile,
      {
        clipPath: CLIP_TILE_OPEN,
        y: 0,
        duration: 0.18,
      },
      0.72,
    );

    chips.forEach((chip, index) => {
      timeline.to(
        chip,
        {
          y: index === 1 ? 5 : -6,
          duration: 0.26,
        },
        0.74,
      );
    });

    ScrollTrigger.refresh();

    return () => {
      timeline.scrollTrigger?.kill();
      timeline.kill();
      killAboutTriggers();
    };
  }

  const cleanups: Array<() => void> = [];

  const proofTween = gsap.fromTo(
    proof,
    {
      autoAlpha: 0.35,
    },
    {
      autoAlpha: 1,
      ease: "none",
      scrollTrigger: {
        id: `${ABOUT_TRIGGER_ID}-proof`,
        trigger: scope,
        start: "top 92%",
        end: "top 58%",
        scrub: true,
      },
    },
  );

  cleanups.push(() => {
    proofTween.scrollTrigger?.kill();
    proofTween.kill();
  });

  const leadTimeline = gsap.timeline({
    defaults: {
      ease: "none",
    },
    scrollTrigger: {
      id: `${ABOUT_TRIGGER_ID}-lead`,
      trigger: select(".v2-about-lead"),
      start: "top 78%",
      end: "bottom 32%",
      scrub: true,
    },
  });

  revealWords(leadTimeline, leadWords, 0, 1, 2.5);

  cleanups.push(() => {
    leadTimeline.scrollTrigger?.kill();
    leadTimeline.kill();
  });

  const followTimeline = gsap.timeline({
    defaults: {
      ease: "none",
    },
    scrollTrigger: {
      id: `${ABOUT_TRIGGER_ID}-follow`,
      trigger: select(".v2-about-follow"),
      start: "top 80%",
      end: "bottom 28%",
      scrub: true,
    },
  });

  revealWords(followTimeline, fastWords, 0, 0.28, 1.1);
  revealWords(followTimeline, restWords, 0.22, 1, 2.3);

  cleanups.push(() => {
    followTimeline.scrollTrigger?.kill();
    followTimeline.kill();
  });

  const tileTimeline = gsap.timeline({
    defaults: {
      ease: "none",
    },
    scrollTrigger: {
      id: `${ABOUT_TRIGGER_ID}-tile`,
      trigger: tile,
      start: "top 88%",
      end: "top 48%",
      scrub: true,
    },
  });

  tileTimeline.to(
    tile,
    {
      clipPath: CLIP_TILE_OPEN,
      y: 0,
      duration: 0.7,
    },
    0,
  );

  chips.forEach((chip, index) => {
    tileTimeline.to(
      chip,
      {
        y: index === 1 ? 4 : -5,
        duration: 0.55,
      },
      0.2,
    );
  });

  cleanups.push(() => {
    tileTimeline.scrollTrigger?.kill();
    tileTimeline.kill();
  });

  ScrollTrigger.refresh();

  return () => {
    cleanups.forEach((cleanup) => {
      cleanup();
    });
    killAboutTriggers();
  };
}

export function playAboutScene(
  scope: HTMLElement,
): gsap.Context {
  return createSceneContext(scope, () => {
    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (reducedMotion) {
      settleAbout(scope);
      return;
    }

    const matchMedia = gsap.matchMedia();

    matchMedia.add(
      "(min-width: 1024px)",
      () =>
        buildAboutTimeline(
          scope,
          "desktop",
        ),
    );

    matchMedia.add(
      "(max-width: 1023px)",
      () =>
        buildAboutTimeline(
          scope,
          "mobile",
        ),
    );

    return () => {
      matchMedia.revert();
    };
  });
}
