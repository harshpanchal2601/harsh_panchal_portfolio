"use client";

import { useLayoutEffect, useRef } from "react";

import { V2Header } from "@/components/portfolio-v2/layout/v2-header";
import { HeroHeadline } from "@/components/portfolio-v2/scenes/hero/hero-headline";
import { HeroIntroTitle } from "@/components/portfolio-v2/scenes/hero/hero-intro-title";
import { HeroMedia } from "@/components/portfolio-v2/scenes/hero/hero-media";
import { playHeroOpening } from "@/components/portfolio-v2/scenes/hero/hero-motion";

import "@/components/portfolio-v2/scenes/hero/hero-scene.css";

export function HeroScene() {
  const rootRef = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const root = rootRef.current;

    if (!root) {
      return;
    }

    /*
     * Previous preview versions used #work / #about / #experience.
     * Those sections do not exist yet.
     *
     * Remove stale development hashes without reloading the page.
     */
    if (window.location.hash) {
      window.history.replaceState(
        window.history.state,
        "",
        `${window.location.pathname}${window.location.search}`,
      );
    }

    const context = playHeroOpening(root);

    return () => {
      context.revert();
    };
  }, []);

  return (
    <section
      ref={rootRef}
      aria-label="Opening"
      className="v2-hero"
      data-hero-state="intro"
    >
      <HeroMedia />

      <HeroHeadline />

      <HeroIntroTitle />

      <V2Header />
    </section>
  );
}
