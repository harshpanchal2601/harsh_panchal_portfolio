import {
  gsap,
  ScrollTrigger,
} from "@/animations/gsap/register-plugins";

import { createSceneContext } from "@/components/portfolio-v2/motion/scene-context";

const CAPABILITIES_TRIGGER_ID = "v2-capabilities-master";

const COLOR_TEXT = "#F3E4D0";
const COLOR_ACCENT = "#B96143";
const COLOR_INACTIVE = "rgba(243, 228, 208, 0.29)";
const COLOR_COMPLETED = "rgba(243, 228, 208, 0.5)";
const COLOR_FAINT = "rgba(243, 228, 208, 0.12)";
const COLOR_MUTED = "rgba(243, 228, 208, 0.28)";
const COLOR_LINE = "rgba(243, 228, 208, 0.14)";
const COLOR_LINE_ACTIVE = "rgba(243, 228, 208, 0.28)";

const STATE_STARTS = [0.18, 0.32, 0.46, 0.6, 0.74] as const;

type TakeoverGeometry = {
  x: number;
  y: number;
  width: number;
  height: number;
};

function killCapabilitiesTrigger(): void {
  ScrollTrigger.getById(CAPABILITIES_TRIGGER_ID)?.kill();
}

function readCoordinate(
  scope: HTMLElement,
  stateIndex: number,
  nodeIndex: number,
  axis: "x" | "y",
): number {
  const value = getComputedStyle(scope).getPropertyValue(
    `--cap-s${stateIndex}-n${nodeIndex}-${axis}`,
  );

  return Number.parseFloat(value) || 50;
}

function readScrollDistance(scope: HTMLElement): number {
  const value = getComputedStyle(scope).getPropertyValue(
    "--cap-scroll-distance",
  );

  return Number.parseFloat(value) || 420;
}

function nodeOffset(
  scope: HTMLElement,
  system: HTMLElement,
  stateIndex: number,
  nodeIndex: number,
  axis: "x" | "y",
): number {
  const percentage = readCoordinate(scope, stateIndex, nodeIndex, axis);
  const dimension = axis === "x" ? system.clientWidth : system.clientHeight;

  return ((percentage - 50) / 100) * dimension;
}

function setVisualState(
  scope: HTMLElement,
  stateIndex: number,
): void {
  const select = gsap.utils.selector(scope);
  const system = select("[data-cap-system]")[0] as HTMLElement | undefined;
  const nodes = gsap.utils.toArray<HTMLElement>(select("[data-cap-node]"));
  const connectors = gsap.utils.toArray<SVGLineElement>(
    select("[data-cap-connector]"),
  );

  if (!system) {
    return;
  }

  nodes.forEach((node, nodeIndex) => {
    gsap.set(node, {
      x: nodeOffset(scope, system, stateIndex, nodeIndex, "x"),
      y: nodeOffset(scope, system, stateIndex, nodeIndex, "y"),
    });
  });

  connectors.forEach((connector, nodeIndex) => {
    gsap.set(connector, {
      attr: {
        x2: readCoordinate(scope, stateIndex, nodeIndex, "x"),
        y2: readCoordinate(scope, stateIndex, nodeIndex, "y"),
      },
    });
  });

  gsap.set(
    select("[data-cap-node-label], [data-cap-core-label]"),
    {
      autoAlpha: 0,
    },
  );

  gsap.set(
    select(
      `[data-cap-node-label="${stateIndex}"], [data-cap-core-label="${stateIndex}"]`,
    ),
    {
      autoAlpha: 1,
    },
  );
}

function previewVisualState(
  scope: HTMLElement,
  stateIndex: number,
): void {
  const select = gsap.utils.selector(scope);
  const system = select("[data-cap-system]")[0] as HTMLElement | undefined;
  const nodes = gsap.utils.toArray<HTMLElement>(select("[data-cap-node]"));
  const connectors = gsap.utils.toArray<SVGLineElement>(
    select("[data-cap-connector]"),
  );

  if (!system) {
    return;
  }

  gsap.to(select("[data-cap-node-label], [data-cap-core-label]"), {
    autoAlpha: 0,
    duration: 0.16,
    overwrite: "auto",
  });

  gsap.to(
    select(
      `[data-cap-node-label="${stateIndex}"], [data-cap-core-label="${stateIndex}"]`,
    ),
    {
      autoAlpha: 1,
      duration: 0.2,
      delay: 0.08,
      overwrite: "auto",
    },
  );

  nodes.forEach((node, nodeIndex) => {
    gsap.to(node, {
      x: nodeOffset(scope, system, stateIndex, nodeIndex, "x"),
      y: nodeOffset(scope, system, stateIndex, nodeIndex, "y"),
      duration: 0.38,
      ease: "power2.out",
      overwrite: "auto",
    });
  });

  connectors.forEach((connector, nodeIndex) => {
    gsap.to(connector, {
      attr: {
        x2: readCoordinate(scope, stateIndex, nodeIndex, "x"),
        y2: readCoordinate(scope, stateIndex, nodeIndex, "y"),
      },
      stroke: stateIndex === 4 && nodeIndex === 3
        ? COLOR_ACCENT
        : COLOR_LINE_ACTIVE,
      duration: 0.38,
      ease: "power2.out",
      overwrite: "auto",
    });
  });
}

function stateAtProgress(progress: number): number {
  let activeState = 0;

  STATE_STARTS.forEach((start, stateIndex) => {
    if (progress >= start) {
      activeState = stateIndex;
    }
  });

  return activeState;
}

function settleCapabilities(scope: HTMLElement): void {
  const select = gsap.utils.selector(scope);
  const rows = gsap.utils.toArray<HTMLElement>(select("[data-cap-row]"));

  gsap.set(select("[data-cap-takeover]"), {
    autoAlpha: 0,
  });

  gsap.set(select("[data-cap-chapter-kicker], [data-cap-chapter-line]"), {
    autoAlpha: 1,
    yPercent: 0,
  });

  gsap.set(select("[data-cap-workspace]"), {
    autoAlpha: 1,
  });

  rows.forEach((row, index) => {
    const active = index === rows.length - 1;

    gsap.set(row.querySelector(".v2-cap-row-number"), {
      color: active ? COLOR_ACCENT : COLOR_COMPLETED,
    });

    gsap.set(row.querySelector(".v2-cap-row-title"), {
      color: active ? COLOR_TEXT : COLOR_COMPLETED,
    });

    gsap.set(row.querySelector(".v2-cap-row-description"), {
      color: active ? COLOR_TEXT : COLOR_MUTED,
      opacity: active ? 0.82 : 0.36,
    });

    gsap.set(row.querySelector(".v2-cap-row-technologies"), {
      color: active ? COLOR_MUTED : COLOR_FAINT,
      opacity: active ? 1 : 0.5,
    });
  });

  setVisualState(scope, 4);
}

function buildCapabilitiesTimeline(scope: HTMLElement): () => void {
  killCapabilitiesTrigger();

  const select = gsap.utils.selector(scope);
  const about = document.querySelector<HTMLElement>(".portfolio-v2 .v2-about");
  const aboutStage = about?.querySelector<HTMLElement>(".v2-about-stage");
  const aboutProof = about?.querySelector<HTMLElement>(".v2-about-proof");
  const aboutCopy = about?.querySelector<HTMLElement>(".v2-about-copy");
  const aboutTile = about?.querySelector<HTMLElement>("[data-about-tile]");

  const takeover = select("[data-cap-takeover]")[0] as HTMLElement | undefined;
  const stage = select(".v2-cap-stage")[0] as HTMLElement | undefined;
  const takeoverContent = select(".v2-cap-takeover-content");
  const chapter = select(".v2-cap-chapter");
  const chapterKicker = select("[data-cap-chapter-kicker]");
  const chapterLines = select("[data-cap-chapter-line]");
  const workspace = select("[data-cap-workspace]");
  const system = select("[data-cap-system]")[0] as HTMLElement | undefined;
  const rows = gsap.utils.toArray<HTMLElement>(select("[data-cap-row]"));
  const nodes = gsap.utils.toArray<HTMLElement>(select("[data-cap-node]"));
  const connectors = gsap.utils.toArray<SVGLineElement>(
    select("[data-cap-connector]"),
  );

  if (!about || !aboutStage || !aboutTile || !takeover || !stage || !system) {
    settleCapabilities(scope);
    return () => {};
  }

  const geometry: TakeoverGeometry = {
    x: 0,
    y: 0,
    width: 1,
    height: 1,
  };

  const measureTakeover = () => {
    const aboutRect = about.getBoundingClientRect();
    const stageRect = aboutStage.getBoundingClientRect();
    const tileRect = aboutTile.getBoundingClientRect();
    const stageIsViewportAnchored = window.matchMedia(
      "(min-width: 1024px)",
    ).matches;

    geometry.x = tileRect.left - stageRect.left;
    geometry.y = stageIsViewportAnchored
      ? tileRect.top - stageRect.top
      : window.innerHeight - (aboutRect.bottom - tileRect.top);
    geometry.width = Math.max(1, tileRect.width);
    geometry.height = Math.max(1, tileRect.height);

    gsap.set(takeover, {
      width: geometry.width,
      height: geometry.height,
      transformOrigin: "0 0",
    });
  };

  const setOriginalTileVisibility = (visible: boolean) => {
    gsap.set(aboutTile, {
      autoAlpha: visible ? 1 : 0,
    });
  };

  const setHandoffVisibility = (active: boolean) => {
    setOriginalTileVisibility(!active);
    gsap.set(takeover, {
      autoAlpha: active ? 1 : 0,
    });
  };

  measureTakeover();

  gsap.set(takeover, {
    autoAlpha: 0,
    x: geometry.x,
    y: geometry.y,
    scaleX: 1,
    scaleY: 1,
  });

  gsap.set(chapterKicker, {
    autoAlpha: 0,
    yPercent: 110,
  });

  gsap.set(chapterLines, {
    autoAlpha: 0,
    yPercent: 115,
  });

  gsap.set(workspace, {
    autoAlpha: 0,
  });

  rows.forEach((row) => {
    gsap.set(row.querySelector(".v2-cap-row-number"), {
      color: COLOR_FAINT,
    });
    gsap.set(row.querySelector(".v2-cap-row-title"), {
      color: COLOR_INACTIVE,
    });
    gsap.set(row.querySelector(".v2-cap-row-description"), {
      color: COLOR_MUTED,
      opacity: 0.08,
    });
    gsap.set(row.querySelector(".v2-cap-row-technologies"), {
      color: COLOR_FAINT,
      opacity: 0.18,
    });
  });

  gsap.set(connectors, {
    stroke: COLOR_LINE,
  });

  setVisualState(scope, 0);

  const timeline = gsap.timeline({
    defaults: {
      ease: "none",
    },
    scrollTrigger: {
      id: CAPABILITIES_TRIGGER_ID,
      trigger: scope,
      start: "top top",
      end: () => `+=${window.innerHeight * (readScrollDistance(scope) / 100)}`,
      pin: stage,
      pinSpacing: true,
      scrub: true,
      anticipatePin: 1,
      invalidateOnRefresh: true,
      onRefreshInit: measureTakeover,
      onEnter: () => setHandoffVisibility(true),
      onEnterBack: () => setHandoffVisibility(true),
      onLeaveBack: () => setHandoffVisibility(false),
      onRefresh: (trigger) => {
        setHandoffVisibility(trigger.progress > 0);
      },
    },
  });

  timeline.fromTo(
    takeover,
    {
      x: () => geometry.x,
      y: () => geometry.y,
      scaleX: 1,
      scaleY: 1,
    },
    {
      x: 0,
      y: 0,
      scaleX: () => window.innerWidth / geometry.width,
      scaleY: () => window.innerHeight / geometry.height,
      duration: 0.12,
    },
    0,
  );

  timeline.to(
    takeoverContent,
    {
      autoAlpha: 0,
      duration: 0.055,
    },
    0.025,
  );

  if (aboutProof) {
    timeline.to(
      aboutProof,
      {
        opacity: 0.4,
        duration: 0.1,
      },
      0,
    );
  }

  if (aboutCopy) {
    timeline.to(
      aboutCopy,
      {
        opacity: 0.26,
        duration: 0.1,
      },
      0,
    );
  }

  timeline.to(
    chapterKicker,
    {
      autoAlpha: 1,
      yPercent: 0,
      duration: 0.045,
    },
    0.07,
  );

  timeline.to(
    chapterLines,
    {
      autoAlpha: 1,
      yPercent: 0,
      duration: 0.065,
      stagger: 0.012,
    },
    0.078,
  );

  timeline.to(
    chapter,
    {
      xPercent: 1.5,
      yPercent: -3,
      scale: 0.34,
      duration: 0.075,
    },
    0.115,
  );

  timeline.to(
    workspace,
    {
      autoAlpha: 1,
      duration: 0.055,
    },
    0.135,
  );

  STATE_STARTS.forEach((start, stateIndex) => {
    const row = rows[stateIndex];
    const previousRow = rows[stateIndex - 1];

    if (previousRow) {
      timeline.to(
        previousRow.querySelector(".v2-cap-row-number"),
        {
          color: COLOR_COMPLETED,
          duration: 0.045,
        },
        start,
      );
      timeline.to(
        previousRow.querySelector(".v2-cap-row-title"),
        {
          color: COLOR_COMPLETED,
          duration: 0.045,
        },
        start,
      );
      timeline.to(
        previousRow.querySelector(".v2-cap-row-description"),
        {
          color: COLOR_MUTED,
          opacity: 0.34,
          duration: 0.045,
        },
        start,
      );
      timeline.to(
        previousRow.querySelector(".v2-cap-row-technologies"),
        {
          color: COLOR_FAINT,
          opacity: 0.48,
          duration: 0.045,
        },
        start,
      );
    }

    if (row) {
      timeline.to(
        row.querySelector(".v2-cap-row-number"),
        {
          color: COLOR_ACCENT,
          duration: 0.045,
        },
        start,
      );
      timeline.to(
        row.querySelector(".v2-cap-row-title"),
        {
          color: COLOR_TEXT,
          duration: 0.045,
        },
        start,
      );
      timeline.to(
        row.querySelector(".v2-cap-row-description"),
        {
          color: COLOR_TEXT,
          opacity: 0.82,
          duration: 0.045,
        },
        start,
      );
      timeline.to(
        row.querySelector(".v2-cap-row-technologies"),
        {
          color: COLOR_MUTED,
          opacity: 1,
          duration: 0.045,
        },
        start,
      );
    }

    timeline.to(
      select("[data-cap-node-label], [data-cap-core-label]"),
      {
        autoAlpha: 0,
        duration: 0.028,
      },
      start,
    );

    timeline.to(
      select(
        `[data-cap-node-label="${stateIndex}"], [data-cap-core-label="${stateIndex}"]`,
      ),
      {
        autoAlpha: 1,
        duration: 0.045,
      },
      start + 0.018,
    );

    nodes.forEach((node, nodeIndex) => {
      timeline.to(
        node,
        {
          x: () => nodeOffset(scope, system, stateIndex, nodeIndex, "x"),
          y: () => nodeOffset(scope, system, stateIndex, nodeIndex, "y"),
          duration: 0.075,
        },
        start,
      );
    });

    connectors.forEach((connector, nodeIndex) => {
      timeline.to(
        connector,
        {
          attr: {
            x2: () => readCoordinate(scope, stateIndex, nodeIndex, "x"),
            y2: () => readCoordinate(scope, stateIndex, nodeIndex, "y"),
          },
          stroke: stateIndex === 4 && nodeIndex === 3
            ? COLOR_ACCENT
            : COLOR_LINE_ACTIVE,
          duration: 0.075,
        },
        start,
      );
    });
  });

  timeline.to(
    {},
    {
      duration: 0.08,
    },
    0.92,
  );

  const removeCapabilityInteractions = gsap.utils
    .toArray<HTMLButtonElement>(select("[data-cap-select]"))
    .map((button) => {
      const stateIndex = Number.parseInt(button.dataset.capSelect ?? "", 10);

      const onClick = () => {
        const trigger = timeline.scrollTrigger;

        if (!trigger || Number.isNaN(stateIndex)) {
          return;
        }

        const targetProgress = Math.min(0.9, STATE_STARTS[stateIndex] + 0.025);
        const targetScroll = trigger.start + ((trigger.end - trigger.start) * targetProgress);

        window.scrollTo({
          top: targetScroll,
          behavior: "smooth",
        });
      };

      const onPreview = () => {
        if (!Number.isNaN(stateIndex)) {
          previewVisualState(scope, stateIndex);
        }
      };

      const onRestore = () => {
        previewVisualState(scope, stateAtProgress(timeline.progress()));
      };

      button.addEventListener("click", onClick);
      button.addEventListener("pointerenter", onPreview);
      button.addEventListener("pointerleave", onRestore);
      button.addEventListener("focus", onPreview);
      button.addEventListener("blur", onRestore);

      return () => {
        button.removeEventListener("click", onClick);
        button.removeEventListener("pointerenter", onPreview);
        button.removeEventListener("pointerleave", onRestore);
        button.removeEventListener("focus", onPreview);
        button.removeEventListener("blur", onRestore);
      };
    });

  ScrollTrigger.refresh();

  return () => {
    removeCapabilityInteractions.forEach((removeInteraction) => {
      removeInteraction();
    });
    setHandoffVisibility(false);
    timeline.scrollTrigger?.kill();
    timeline.kill();
    killCapabilitiesTrigger();
  };
}

export function playCapabilitiesScene(scope: HTMLElement): gsap.Context {
  return createSceneContext(scope, () => {
    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (reducedMotion) {
      settleCapabilities(scope);
      return;
    }

    return buildCapabilitiesTimeline(scope);
  });
}
