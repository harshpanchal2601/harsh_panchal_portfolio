import { V2_NAV_ITEMS } from "@/components/portfolio-v2/scenes/hero/hero-content";

export function V2Header() {
  return (
    <header className="v2-header">
      <a className="v2-header-wordmark" href="/preview">
        <span className="v2-header-wordmark-full">Harsh Panchal</span>
        <span className="v2-header-wordmark-short">Harsh</span>
      </a>

      <nav className="v2-header-nav" aria-label="V2 preview">
        {V2_NAV_ITEMS.map((label) => (
          <button className="v2-header-link" key={label} type="button">
            {label}
          </button>
        ))}
      </nav>

      <button className="v2-header-talk" type="button">
        Let&apos;s Talk
      </button>

      <button aria-label="Menu" className="v2-header-menu" type="button">
        Menu
      </button>
    </header>
  );
}
