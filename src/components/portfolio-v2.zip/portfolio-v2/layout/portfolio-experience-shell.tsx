"use client";

import { useLayoutEffect, useRef } from "react";
import { useV2ScrollRuntime } from "@/animations/gsap/scroll-runtime";
import "@/components/portfolio-v2/foundation/portfolio-v2.css";

type PortfolioExperienceShellProps = Readonly<{
  children: React.ReactNode;
}>;

export function PortfolioExperienceShell({
  children,
}: PortfolioExperienceShellProps) {
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (!window.location.hash) {
      return;
    }

    const url = new URL(window.location.href);
    url.hash = "";
    window.history.replaceState(null, "", `${url.pathname}${url.search}`);
  }, []);

  useV2ScrollRuntime(rootRef);

  return (
    <div ref={rootRef} className="portfolio-v2" data-portfolio-v2="">
      {children}
    </div>
  );
}
